//From a given set of numbers in array, you need to find out how many number satisfy the Pythagoras template

package com.yash.assignment;

public class A15 
{
	static boolean isTriplet(int ar[], int n)
	{
		for (int i = 0; i < n; i++)
		{
			for (int j = i + 1; j < n; j++)
			{
				for (int k = j + 1; k < n; k++)
				{
	
					int x = ar[i] * ar[i], y = ar[j] * ar[j], z = ar[k] * ar[k];
				
					if (x == y + z || y == x + z || z == x + y)
					return true;
				}
			}
		}
		return false;
	}
	public static void main(String[] args) {
		int ar[] = { 5, 3, 6, 7, 2 };
		int ar_size = ar.length;
		if (isTriplet(ar, ar_size) == true)
		System.out.println("True");
		else
		System.out.println("False");
	}
}
